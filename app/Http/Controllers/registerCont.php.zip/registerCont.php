<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Admin\Sekolah;
use Illuminate\Support\Facades\Hash;
class registerCont extends Controller
{
    //
    public function index()
    {
        $sekolah=Sekolah::all();
    	return view('portal.signup.signup',compact('sekolah'));
    }

    public function post(Request $request)
    {
        $this->validate($request, [
            'nama'    => 'required',
            'telp'   => 'required',
            'email' => 'required|email',
            'password' => 'required',
            // 'g-recaptcha-response' => 'required|captcha',
        ]);
        $password=$request->password;
        $password1=Hash::make($password);
        User::create([
            'name'      => $request->nama,
            'email'     => $request->email,
            'password'   => $password1,
            'level'   => 'MEMBER',
            'aktif'   => 'N',
            'kontak'   => $request->telp,
            'id_sekolah'=>$request->sekolah,
        ]);
        return redirect()->route('register')->with(['success' => 'Registrasi berhasil.']);
    }
}
